package FirstBank;

public class FirstBank {
    public static void main(String[] args) {

        Account tim = new Account("Tim Drake", "U00001");
        tim.showMenu();
    }
}
